# Energy Consumption Analytics – BI Mini Project

## Business Problem
Analyze electricity consumption trends to identify high-demand regions and improve efficiency.

## Data Sources
- CSV: Household Power Consumption (UCI)
- SQL: Households, Regions, Tariff Plans

## ETL
- Cleaned data, handled missing values
- Merged CSV with SQL
- Created cost and date dimensions

## KPIs
- Total Energy Consumed
- Average Household Consumption
- Estimated Energy Cost

## Screenshots
See dashboard.png and model.png
