USE EnergyDB;
CREATE TABLE Regions(region_id INT PRIMARY KEY, region_name VARCHAR(50));
CREATE TABLE Tariff_Plans(tariff_id INT PRIMARY KEY, tariff_name VARCHAR(50), tariff_rate DECIMAL(5,2));
CREATE TABLE Households(household_id INT PRIMARY KEY, household_type VARCHAR(50), region_id INT, tariff_id INT);
